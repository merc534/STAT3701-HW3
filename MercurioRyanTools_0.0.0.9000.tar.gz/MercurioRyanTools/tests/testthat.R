library(testthat)
library(MercurioRyanTools)

test_check("MercurioRyanTools")
