## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- fig.show='hold'----------------------------------------------------
library("MercurioRyanTools")
library("tidyverse")
plottr(data1)

data3 <- 1:30
data4 <- data.frame(data3, data2)
plottr(data4)
plottr(data1, col="yellow", size = 10)

## ---- echo=FALSE, results='asis'-----------------------------------------
knitr::kable(data1)
knitr::kable(data4)

