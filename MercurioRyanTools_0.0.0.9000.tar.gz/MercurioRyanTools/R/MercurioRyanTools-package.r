#' MercurioRyanTools.
#'
#' @name MercurioRyanTools
#' @docType package
NULL
