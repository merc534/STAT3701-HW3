
#'Log Likelihood Estimator 
#'
#' Using a data vector and the log of its CDF, find the maximum likelihood estimator for a given interval.
#' 
#'Example functions for argument "fun":
#'function(theta,x)
#'  sum(dgamma(x, shape = theta, log = TRUE))
#'
#'function(theta,x)
#'  sum(dcauchy(x, location = theta, log = TRUE))
#'
#'function(theta,x)
#'  sum(dbinom(x, 20, prob = 1 / (1 + exp(- theta)), log = TRUE))
#'
#'@param x = data vector, func = function with arguments theta (a parameter) and x (the data vector), interval = search range(numerical vector of length 2)
#'@return The maximum likelihood estimator for the function: one numeric value
#'@export


mylogl <- function (x, func, interval)
  {
  
  
  oout <- optimize(func, maximum=T, interval, x=x)
  return (oout$maximum)
}

